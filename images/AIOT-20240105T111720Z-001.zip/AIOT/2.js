var ultrasonic1;
var led1;
var buzzer;
var servo;
var ultrasonic2;

function buzzer_music(m) {
  var musicNotes = {};
  musicNotes.notes = [];
  musicNotes.tempos = [];
  if (m[0].notes.length > 1) {
    for (var i = 0; i < m.length; i++) {
      if (Array.isArray(m[i].notes)) {
        var cn = musicNotes.notes.concat(m[i].notes);
        musicNotes.notes = cn;
      } else {
        musicNotes.notes.push(m[i].notes);
      }
      if (Array.isArray(m[i].tempos)) {
        var ct = musicNotes.tempos.concat(m[i].tempos);
        musicNotes.tempos = ct;
      } else {
        musicNotes.tempos.push(m[i].tempos);
      }
    }
  } else {
    musicNotes.notes = [m[0].notes];
    musicNotes.tempos = [m[0].tempos];
  }
  return musicNotes;
}


boardReady({device: 'A7KaK'}, function (board) {
  board.samplingInterval = 1000;
  ultrasonic1 = getUltrasonic(board, 10, 11);
  buzzer = getBuzzer(board, 7);
  led1 = getLed(board, 6);
  ultrasonic2 = getUltrasonic(board, 12, 13);
  ultrasonic1.ping(function (cm) {
    if (ultrasonic1.distance < 10) {
      document.getElementById('demo-area-01-show').innerHTML = '滿';
      led1.on();
      buzzer.play(buzzer_music([{ notes:['E7','E7','0','E7','0','C7','E7','0','G7','0','0','0','G6','0','0','0','C7','0','0','G6','0','0','E6','0','0','A6','0','B6','0','AS6','A6','0','G6','E7','0','G7','A7','0','F7','G7','0','E7','0','C7','D7','B6','0','0','C7','0','0','G6','0','0','E6','0','0','A6','0','B6','0','AS6','A6','0','G6','E7','0','G7','A7','0','F7','G7','0','E7','0','C7','D7','B6','0','0'] , tempos:['8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8'] }]).notes ,buzzer_music([{ notes:['E7','E7','0','E7','0','C7','E7','0','G7','0','0','0','G6','0','0','0','C7','0','0','G6','0','0','E6','0','0','A6','0','B6','0','AS6','A6','0','G6','E7','0','G7','A7','0','F7','G7','0','E7','0','C7','D7','B6','0','0','C7','0','0','G6','0','0','E6','0','0','A6','0','B6','0','AS6','A6','0','G6','E7','0','G7','A7','0','F7','G7','0','E7','0','C7','D7','B6','0','0'] , tempos:['8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8'] }]).tempos );
    } else {
      document.getElementById('demo-area-01-show').innerHTML = '未滿';
      led1.off();
      buzzer.stop();
    }
  }, 500);
});
