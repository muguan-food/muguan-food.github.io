import requests

def call_api():
    # 替换以下URL为您要调用的API的实际URL
    api_url = 'https://script.google.com/macros/s/AKfycbzCgOYTasQSTtN11Z6U9z15_o6qn5C65nSN6sehi06ZVo3O8W96w_-MmCT_NQA5YBR9/exec'
    
    try:
        # 发起GET请求
        response = requests.get(api_url)
        
        # 检查响应状态码
        if response.status_code == 200:
            # 处理API响应数据，这取决于API的返回格式
            api_data = response.json()  # 假设API返回JSON数据
            print("API Response:", api_data)
        else:
            print("Failed to call API. Status Code:", response.status_code)
            
    except Exception as e:
        print("An error occurred:", e)

# 调用API函数
call_api()
