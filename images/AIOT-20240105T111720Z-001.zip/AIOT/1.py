from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app)

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('control_arduino')
def handle_control_arduino(data):
    # 在這裡處理從前端接收到的資料，例如控制指令
    print("Received data:", data)
    # 在這裡加上控制Arduino的程式碼，使用WebSocket或HTTP請求


if __name__ == '__main__':
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
